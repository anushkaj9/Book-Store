<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>the hare krishna movement</h3>
   <p> <a href="home.php">Home</a> / About </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="https://qph.fs.quoracdn.net/main-qimg-dcaba55b588a8ab23262ce41f5592bfe" alt="">
      </div>

      <div class="content">
         <h3>Why choose Srila Prabhupada Books?</h3>
         <p>The Bhaktivedanta Book Trust (BBT) is the world's largest publisher of books on Vedic literature and the philosophy, religion, and culture of the Vedic tradition of India. Its publications include original scriptural works, translated into more than 100 languages, and books that discuss and explain these traditional texts.

BBT publishes the Bhagavad-gita, Srimad-Bhagavatam, Isopanisad, Narada-bhakti-sutra, and the Sri Chaitanya-charitamrta, and numerous other books. These books teach people how to lead a healthy, happy and contended life. These books cater to the overall well being of the person.

The BBT was established in 1972 by His Divine Grace A.C. Bhaktivedanta Swami Prabhupada, Founder-Acharya of the International Society for Krishna Consciousness. BBT is the publisher for his books.

Srila Prabhupada personally registered the BBT in India in March 1972 under the Bombay Public Trust Act 1950 with registration number E 5032 (BOM).</p>
         <p>For Retailers : A whole read of authentic spiritual literature as it is.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">Scholars Praise Srila Prabhupada's Books</h1>

   <div class="box-container">

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.eSIBybX-XtmtvidTxPDC7QHaHa?w=158&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"No work in all Indian literature is more quoted, because none is better loved, in the West, than the Bhagavad-gita. Translation of such a work demands not only knowledge of Sanskrit, but an inward sympathy with the theme and a verbal artistry. For the poem is a symphony in which God is seen in all things....The Swami does a real service for students by investing the beloved Indian epic with fresh meaning. Whatever our outlook may be, we should all be grateful for the labor that has lead to this illuminating work."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Dr. Geddes MacGregor, Emeritus Distinguished Professor of Philosophy
University of Southern California</h3>
      </div>

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.JgjUDjG7pgOhctUg8Jp7YQHaE8?w=240&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"I am most impressed with A.C. Bhaktivedanta Swami Prabhupada's scholarly and authoritative edition of Bhagavad-gita. It is a most valuable work for the scholar as well as the layman and is of great utility as a reference book as well as a textbook. I promptly recommend this edition to my students. It is a beautifully done book."

</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Dr. Samuel D. Atkins
Professor of Sanskrit, Princeton University</h3>
      </div>

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.bDQC0OuH1wExuSKqUpsBUgHaJS?w=121&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"The Gita can be seen as the main literary support for the great religious civilization of India, the oldest surviving culture in the world. The present translation and commentary is another manifestation of the permanent living importance of the Gita."

</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Thomas Merton,
Theologian</h3>
      </div>

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.EO4EKD6jITSlUJ2zQeJpjAHaFk?w=210&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"I have had the opportunity of examining several volumes published by the Bhaktivedanta Book Trust and have found them to be of excellent quality and of great value for use in college classes on Indian religions. This is particularly true of the BBT edition and translation of the Bhagavad-gita."

</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Dr. Frederick B. Underwood
Professor of Religion, Columbia University</h3>
      </div>

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.lrKkrpE_jdxiHLIz6H_OigHaDt?w=311&h=174&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"...As a successor in direct line from Caitanya, the author of Bhagavad-gita As It Is is entitled, according to Indian custom, to the majestic title of His Divine Grace A.C. Bhaktivedanta Swami Prabhupada. The great interest that his reading of the Bhagavad-gita holds for us is that it offers us an authorized interpretation according to the principles of the Caitanya tradition."

</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Olivier Lacombe
Professor of Sanskrit and Indology, Sorbonne University, Paris</h3>
      </div>

      <div class="box">
         <img src="https://th.bing.com/th/id/OIP.FIM87mY_Yk7gLMGSv1QPJAAAAA?w=169&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="">
         <p>"...It is a deeply felt, powerfully conceived and beautifully explained work. I don't know whether to praise more this translation of the Bhagavad-gita, its daring method of explanation, or the endless fertility of its ideas. I have never seen any other work on the Gita with such an important voice and style....It will occupy a significant place in the intellectual and ethical life of modern man for a long time to come."

</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Dr. Shaligram Shukla
Professor of Linguistics, Georgetown University</h3>
      </div>

   </div>

</section>



<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>