<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php">Home</a>
         <a href="about.php">About</a>
         <a href="shop.php">Shop</a>
         <a href="contact.php">Contact</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="login.php">Login</a>
         <a href="register.php">Register</a>
         <a href="cart.php">Cart</a>
         <a href="orders.php">Orders</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> +123-456-7890 </p>
         <p> <i class="fas fa-phone"></i> +111-222-3333 </p>
         <p> <i class="fas fa-envelope"></i> iskconbooks@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Indore, India - 452016 </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="https://instagram.com/iskconindore?igshid=ODM2MWFjZDg="> <i class="fab fa-instagram"></i> Instagram </a>
         <a href="#"> <i class="fab fa-linkedin"></i> Linkedin </a>
         <a href="https://www.youtube.com/@iskconindore"> <i class="fab fa-youtube"></i> Youtube </a>
      </div>

   </div>

   <p class="credit"> &copy; His Divine Grace A.C. Bhaktivedanta Swami Prabhupāda, Founder-Ācārya of the International Society for Krishna Consciousness.
Content used with permission of © The Bhaktivedanta Book Trust International, Inc. All rights reserved.  @ <?php echo date('Y'); ?> by <span> iskconbooks </span> </p>

</section>